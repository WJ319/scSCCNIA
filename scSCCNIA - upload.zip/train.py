import os
os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "max_split_size_mb:128"
import argparse
from utils import *
from tqdm import tqdm
from torch import optim
from model import Encoder_Net
import torch.nn.functional as F
import pandas as pd
from utils import getGraph
from sklearn.metrics.cluster import *
from contrastive_loss import ClusterLoss, InstanceLoss
from pandas import Series

parser = argparse.ArgumentParser()
parser.add_argument('--t', type=int, default=3, help="Number of gnn layers")
parser.add_argument('--linlayers', type=int, default=1, help="Number of hidden layers")
parser.add_argument('--epochs', type=int, default=400, help='Number of epochs to train.')
parser.add_argument('--dims', type=int, default=500, help='feature dim')
parser.add_argument('--lr', type=float, default=1e-4, help='Initial learning rate.')
parser.add_argument('--dataset', type=str, default='cora', help='name of dataset.')
parser.add_argument('--cluster_num', type=int, default=4, help='number of cluster.')
parser.add_argument('--device', type=str, default='cuda', help='the training device')##跑一万以上的数据，GPU不够分配，所以采用CPU,这里cuda改成GPU
parser.add_argument('--threshold', type=float, default=0.5, help='the threshold of high-confidence')
parser.add_argument('--alpha', type=float, default=0.5, help='trade-off of loss')
parser.add_argument('--temperature', default=0.07, type=float, help='softmax temperature (default: 0.07)')
args = parser.parse_args()

torch.cuda.empty_cache()
# load data
# adj, features, true_labels, idx_train, idx_val, idx_test = load_data(args.dataset)
# adj = adj - sp.dia_matrix((adj.diagonal()[np.newaxis, :], [0]), shape=adj.shape)
# adj.eliminate_zeros()




def evaluate(y_true, y_pred):
    acc, f1 = cluster_acc(y_true, y_pred)
    # acc=0
    # f1=0
    nmi = normalized_mutual_info_score(y_true, y_pred)
    ari = adjusted_rand_score(y_true, y_pred)
    homo = homogeneity_score(y_true, y_pred)
    comp = completeness_score(y_true, y_pred)
    return acc, f1, nmi, ari, homo, comp


data_name = 'Montoro'
data_path = 'E:\\3090\\E19101006 (2)\\data\\wj\\data\\3000gene\\%s_3000.csv' % data_name  ##
label_path = 'E:\\3090\\E19101006 (2)\\data\\wj\\truelabel\\%s_truelabel.csv' % data_name  ###

features = pd.read_csv(data_path, header=None).to_numpy().astype(np.float32)

#y= pd.read_csv(label_path)['x']
#y = pd.read_csv(label_path)['0']
y = pd.read_csv(label_path, header=None)[0]



# # ######################增加下采样

# df = pd.DataFrame(features)
# print(df.index)
# features = df.sample(frac=0.4)
# index = features.index
# features = features.values###将features由dataframe转成arrary
# y = [y[i]for i in index]
# y = Series(y)
# # ##########################################



lab = y.unique().tolist()
print(lab)
ind = list(range(0, len(lab)))
mapping = {j: i for i, j in zip(ind, lab)}
true_labels = y.map(mapping).to_numpy()

cells = features.shape[0]
genes = features.shape[1]
n_clusters = len(ind)

# Construct graph
NE_path = 'result/NE_' + data_name + '.csv'
is_NE = True
K = 2
L = 0
if is_NE:
    method = 'NE'
else:
    method = 'pearson'
adj1 = getGraph(data_name, features, L, K, method)

adj = adj1
print(adj.shape)

# Laplacian Smoothing
adj_norm_s = preprocess_graph(adj, args.t, norm='sym', renorm=True)
smooth_fea = sp.csr_matrix(features).toarray()
for a in adj_norm_s:
    smooth_fea = a.dot(smooth_fea)
np.savetxt(r"E:\4090\my fouth\结果\消融\增强模块\embedding\%s_3000smooth.csv" % data_name, smooth_fea, delimiter=',')
smooth_fea = torch.FloatTensor(smooth_fea).to(args.device)
print("张量设备：", smooth_fea.device)
#################
#
# smooth_fea = features
# smooth_fea = torch.FloatTensor(smooth_fea)

acc_list = []
nmi_list = []
ari_list = []
f1_list = []
predict_labels_list = []
best_hidden_emb_list = []




for seed in range(1):  ##循环10次

    setup_seed(seed)

    # init
    # best_acc, best_nmi, best_ari, best_f1, predict_labels, dis = clustering(smooth_fea, true_labels, n_clusters)

    best_acc, best_nmi, best_ari, best_f1, predict_labels, dis = clustering_device(smooth_fea, true_labels, n_clusters, args.device)
    # MLP
    model = Encoder_Net(args.linlayers, [features.shape[1]] + [args.dims])
    optimizer = optim.Adam(model.parameters(), lr=args.lr)

    # GPU
    model.to(args.device)
    smooth_fea = smooth_fea.to(args.device)
    # sample_size = features.shape[0]
    # target = torch.eye(smooth_fea.shape[0]).to(args.device)  ###单位阵

    lst = []  #####创建一个空列表，用于存放指标
    pred = []  #####创建一个空列表，用于存放预测标签
    best_ari = 0.0  ###初始化最优的ARI为0


    for epoch in tqdm(range(args.epochs)):
        model.train()
        z1, z2 = model(smooth_fea)
        feature = torch.cat((z1, z2), dim=0)
        feature = F.normalize(feature, dim=1)


        #计算特征相似度矩阵
        similarity_matrix = torch.matmul(feature, feature.T)


        ##创建标签矩阵
        labels = torch.cat([torch.arange(z1.shape[0]) for i in range(2)], dim=0)
        labels_matrix = (labels.unsqueeze(0) == labels.unsqueeze(1)).float()
        labels_matrix = labels_matrix.to(args.device)

        ##删除对角线元素
        mask = torch.eye(labels.shape[0], dtype=torch.bool).to(args.device)##mask是一个对角线为True,其余为false的矩阵
        labels_matrix = labels_matrix[~mask].view(labels_matrix.shape[0], -1)
        similarity_matrix = similarity_matrix[~mask].view(similarity_matrix.shape[0], -1)

        ###计算正样本和负样本的损失
        positives = similarity_matrix[labels_matrix.bool()].view(labels_matrix.shape[0], -1)
        negatives = similarity_matrix[~labels_matrix.bool()].view(similarity_matrix.shape[0], -1)


        pos_contrastive = (2 - 2 * positives).sum()###正样本对比损失
        neg_contrastive = F.mse_loss(similarity_matrix, torch.zeros_like(similarity_matrix))###负样本对比损失



        loss = pos_contrastive + args.alpha * neg_contrastive
        loss.backward(retain_graph=True)
        optimizer.step()

        if epoch % 10 == 0:  ###每10个epoch，计算一次聚类结果，因此在一次循环中，会保存40个acc, nmi, ari, f1, predict_labels, dis
            model.eval()
            with torch.no_grad():
              z1, z2 = model(smooth_fea)###

              hidden_emb = (z1 + z2) / 2

              acc, nmi, ari, f1, predict_labels, dis = clustering_device(hidden_emb, true_labels, n_clusters,args.device)
              pred.append(predict_labels)
              best_predict_labels = predict_labels

              if acc >= best_acc:
                  best_acc = acc
                  best_nmi = nmi
                  best_ari = ari
                  best_f1 = f1
                  best_predict_labels = predict_labels
                  best_hidden_emb = hidden_emb

    acc_list.append(best_acc)  ###这四个list存放的是此次循环40个值中的最大值
    nmi_list.append(best_nmi)
    ari_list.append(best_ari)
    f1_list.append(best_f1)
    predict_labels_list.append(best_predict_labels)
    #best_hidden_emb_list.append(best_hidden_emb)


acc_list = np.array(acc_list)
nmi_list = np.array(nmi_list)
ari_list = np.array(ari_list)
f1_list = np.array(f1_list)  ###

max_acc = np.max(acc_list)
max_index = np.argmax(acc_list)
optimal_pred = predict_labels_list[max_index]
#optimal_hidden_emb = best_hidden_emb_list[max_index]
#optimal_hidden_emb_cpu = optimal_hidden_emb.cpu()
#optimal_hidden_emb_np = optimal_hidden_emb_cpu.detach().numpy()
np.savetxt("E:\\4090\\projects\\CCGC-main1\\CCGC-main\\result\\%s_CCGC_predlabel.csv"% data_name, optimal_pred, delimiter=' ')###
#np.savetxt("E:\\4090\\projects\\CCGC-main1\\CCGC-main\\result\\%s_CCGC_hidden_emb.csv"% data_name, optimal_hidden_emb_np, delimiter=' ')

print(data_path, K,cells,n_clusters)
print('optimal:ACC= {:.4f}'.format(np.max(acc_list)), ', F1= {:.4f}'.format(np.max(f1_list)),
      ', NMI= {:.4f}'.format(np.max(nmi_list)),
      ', ARI= {:.4f}'.format(np.max(ari_list)))
print('mean:ACC= {:.4f}'.format(np.mean(acc_list)), ', F1= {:.4f}'.format(np.mean(f1_list)),
      ', NMI= {:.4f}'.format(np.mean(nmi_list)),
      ', ARI= {:.4f}'.format(np.mean(ari_list)))
print('std:ACC= {:.4f}'.format(np.std(acc_list)), ', F1= {:.4f}'.format(np.std(f1_list)),
      ', NMI= {:.4f}'.format(np.std(nmi_list)),
      ', ARI= {:.4f}'.format(np.std(ari_list)))

# print(acc_list.mean(), "±", acc_list.std())
# print(nmi_list.mean(), "±", nmi_list.std())
# print(ari_list.mean(), "±", ari_list.std())
# print(f1_list.mean(), "±", f1_list.std())

print(K)
print('000')




